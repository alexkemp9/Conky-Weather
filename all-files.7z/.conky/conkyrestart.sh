#!/bin/bash
killall -SIGUSR1 conky

