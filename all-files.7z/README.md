# Conky-Weather
How-To Setup a Desktop Barometer + Weather Stats
